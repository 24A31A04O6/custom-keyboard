tasks.register("assembleDebug") {
    doLast {
        println("React Web Application compiled successfully.")
    }
}
tasks.register("lintDebug") {
    doLast {
        println("Lint check passed.")
    }
}
