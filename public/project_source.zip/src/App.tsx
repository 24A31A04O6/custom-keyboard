import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  KeyboardMode,
  ShiftState,
  ThemeId,
  SoundPackId,
  AppSettings,
  KeyboardStats,
  ClipItem,
  EditorInputType,
  ImeAction
} from './types';
import { deletePreviousGrapheme, deletePreviousWord, getAdjacentGraphemePos } from './utils/textUtils';
import { Toolbar } from './components/Toolbar';
import { SuggestionBar } from './components/SuggestionBar';
import { KeyboardLayout } from './components/KeyboardLayout';
import { EmojiKeyboard } from './components/EmojiKeyboard';
import { ClipboardDrawer } from './components/ClipboardDrawer';
import { PhrasesPanel } from './components/PhrasesPanel';
import { StatsPanel } from './components/StatsPanel';
import { VoiceTypingPanel } from './components/VoiceTypingPanel';
import { ToolbarCustomizer } from './components/ToolbarCustomizer';
import { SettingsModal } from './components/SettingsModal';
import { TypingArea, SAMPLE_PROMPTS } from './components/TypingArea';
import { soundController } from './utils/audio';
import {
  getSuggestions,
  checkGrammar,
  getSmartReplies,
  getAutoCorrection,
  autoCorrectSentence,
  translateText,
  detectOtp,
  checkShortcut
} from './utils/engine';
import { Settings, Moon, Sun, Smartphone } from 'lucide-react';

const DEFAULT_SETTINGS: AppSettings = {
  autoCorrectEnabled: true,
  autoCapsEnabled: true,
  spellCheckEnabled: true,
  grammarCheckEnabled: true,
  smartComposeEnabled: true,
  aiRepliesEnabled: true,
  blockOffensiveEnabled: true,
  swipeTypingEnabled: true,
  voiceTypingEnabled: true,
  soundPack: SoundPackId.MECHANICAL,
  soundVolume: 75,
  hapticEnabled: true,
  selectedTheme: ThemeId.DARK,
  customBackgroundUrl: null,
  keyboardHeightDp: 290,
  keyFontSize: 16,
  toolbarButtons: ['clipboard', 'translate', 'autocorrect', 'emoji', 'theme', 'settings', 'voice', 'undo', 'phrases', 'stats'],
  personalDictionary: ['BabelKey', 'Namaste', 'Hyderabad', 'Bangalore'],
  shortcuts: {
    brb: 'Be right back',
    omw: 'On my way!',
    ty: 'Thank you!',
    np: 'No problem!',
    gn: 'Good night!',
  },
  quickPhrases: [
    'On my way!',
    'I will call you in a few minutes.',
    'Please send over the documents.',
    'Thank you so much!',
    'Can we reschedule for tomorrow?',
  ],
};

const INITIAL_CLIPS: ClipItem[] = [
  { id: 'clip-1', text: 'https://babelkey.app', pinned: true, createdAt: Date.now() - 3600000 },
  { id: 'clip-2', text: 'Welcome to BabelKey smart keyboard!', pinned: false, createdAt: Date.now() - 1800000 },
  { id: 'clip-3', text: 'Verification Code: 729104', pinned: false, createdAt: Date.now() - 900000 },
];

export const App: React.FC = () => {
  // Main state
  const [text, setText] = useState('');
  const [cursorPos, setCursorPos] = useState(0);
  const [history, setHistory] = useState<string[]>([]);
  const [historyClearedNotice, setHistoryClearedNotice] = useState(false);
  const [keyboardMode, setKeyboardMode] = useState<KeyboardMode>('qwerty');
  const [shiftState, setShiftState] = useState<ShiftState>(ShiftState.OFF);
  const [activePanel, setActivePanel] = useState<string | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // IME & EditorInfo simulation state (Gboard parity)
  const [editorInputType, setEditorInputType] = useState<EditorInputType>('text');
  const [imeAction, setImeAction] = useState<ImeAction>('IME_ACTION_SEND');
  const [lastImeActionFeedback, setLastImeActionFeedback] = useState<string | null>(null);

  const handleEditorInputTypeChange = (type: EditorInputType) => {
    setEditorInputType(type);
    if (type === 'number' || type === 'phone') {
      setKeyboardMode('numpad');
      setImeAction('IME_ACTION_DONE');
    } else if (type === 'email') {
      setImeAction('IME_ACTION_NEXT');
      setKeyboardMode((prev) => (prev === 'numpad' ? 'qwerty' : prev));
    } else if (type === 'password' || type === 'visible_password') {
      setImeAction('IME_ACTION_DONE');
      setKeyboardMode((prev) => (prev === 'numpad' ? 'qwerty' : prev));
    } else {
      setKeyboardMode((prev) => (prev === 'numpad' ? 'qwerty' : prev));
    }
  };

  // Incoming simulated message context (for testing AI smart replies)
  const [sampleIdx, setSampleIdx] = useState(0);
  const incomingMessage = SAMPLE_PROMPTS[sampleIdx];

  // Settings & Storage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('babelkey_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Clips
  const [clips, setClips] = useState<ClipItem[]>(() => {
    try {
      const saved = localStorage.getItem('babelkey_clips');
      return saved ? JSON.parse(saved) : INITIAL_CLIPS;
    } catch {
      return INITIAL_CLIPS;
    }
  });

  // Stats
  const [stats, setStats] = useState<KeyboardStats>(() => {
    try {
      const saved = localStorage.getItem('babelkey_stats');
      return saved
        ? JSON.parse(saved)
        : {
            totalWords: 0,
            totalCharacters: 0,
            sessionStartTime: Date.now(),
            correctionCounts: {},
            dailyWords: {},
          };
    } catch {
      return {
        totalWords: 0,
        totalCharacters: 0,
        sessionStartTime: Date.now(),
        correctionCounts: {},
        dailyWords: {},
      };
    }
  });

  // Save settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('babelkey_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Save clips
  useEffect(() => {
    try {
      localStorage.setItem('babelkey_clips', JSON.stringify(clips));
    } catch {}
  }, [clips]);

  // Save stats
  useEffect(() => {
    try {
      localStorage.setItem('babelkey_stats', JSON.stringify(stats));
    } catch {}
  }, [stats]);

  // Push history snapshot before mutation
  const pushHistory = (current: string) => {
    setHistory((prev) => [...prev.slice(-20), current]);
  };

  // Undo last action
  const handleUndo = () => {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setText(prev);
    setCursorPos(prev.length);
  };

  // Clear typing history buffer immediately to reset memory and avoid bloat in long sessions
  const handleClearHistory = () => {
    if (history.length === 0) return;
    setHistory([]);
    setHistoryClearedNotice(true);
    setTimeout(() => setHistoryClearedNotice(false), 2200);
    soundController.playKeySound(settings.soundPack, settings.soundVolume);
    soundController.triggerHaptic(settings.hapticEnabled);
  };

  // Track typing activity for real-time WPM, active duration, and session metrics
  const trackTypingActivity = (chars = 1, words = 0) => {
    const now = Date.now();
    setStats((prev) => {
      const prevActiveTime = prev.lastActiveTime || now;
      const elapsedSinceLast = now - prevActiveTime;
      // If activity happened within last 4 seconds, add to active typing time
      const additionalActiveSec = elapsedSinceLast < 4000 ? Math.max(0.2, elapsedSinceLast / 1000) : 1;

      // Keep recent activity within the last 60 seconds for burst/instant WPM
      const recentActivity = [
        ...(prev.recentActivity || []).filter((item) => now - item.timestamp < 60000),
        { timestamp: now, chars, words },
      ];

      return {
        ...prev,
        totalCharacters: prev.totalCharacters + chars,
        totalWords: prev.totalWords + words,
        lastActiveTime: now,
        activeTypingSeconds: (prev.activeTypingSeconds || 0) + additionalActiveSec,
        recentActivity,
      };
    });
  };

  // Extract current word preceding the cursor
  const currentWord = useMemo(() => {
    const beforeCursor = text.substring(0, cursorPos);
    const match = beforeCursor.match(/[\w'-]+$/);
    return match ? match[0] : '';
  }, [text, cursorPos]);

  // Strict Privacy Protocol (Android IME standards: TYPE_TEXT_VARIATION_PASSWORD & TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
  const isStrictPrivacy = editorInputType === 'password' || editorInputType === 'visible_password';

  // Predictive suggestions (strictly disabled on password fields per Android IME security standards)
  const suggestions = useMemo(() => {
    if (isStrictPrivacy) return [];
    if (!settings.smartComposeEnabled || !currentWord) return [];
    return getSuggestions(currentWord, settings.personalDictionary);
  }, [currentWord, settings.smartComposeEnabled, settings.personalDictionary, isStrictPrivacy]);

  // Grammar check (strictly disabled on password fields)
  const grammarError = useMemo(() => {
    if (isStrictPrivacy) return null;
    if (!settings.grammarCheckEnabled) return null;
    return checkGrammar(text);
  }, [text, settings.grammarCheckEnabled, isStrictPrivacy]);

  // Smart Replies from incoming message (strictly disabled on password fields)
  const smartReplies = useMemo(() => {
    if (isStrictPrivacy) return [];
    if (!settings.aiRepliesEnabled) return [];
    return getSmartReplies(incomingMessage);
  }, [incomingMessage, settings.aiRepliesEnabled, isStrictPrivacy]);

  // OTP detection from text or recent clip
  const otpDetected = useMemo(() => {
    const fromText = detectOtp(text);
    if (fromText) return fromText;
    for (const clip of clips) {
      const code = detectOtp(clip.text);
      if (code) return code;
    }
    return null;
  }, [text, clips]);

  // Key sound trigger
  const playSoundAndHaptic = () => {
    soundController.playKeySound(settings.soundPack, settings.soundVolume);
    soundController.triggerHaptic(settings.hapticEnabled);
  };

  // Handle regular key press
  const handleKeyPress = (char: string) => {
    playSoundAndHaptic();
    pushHistory(text);

    let insertChar = char;

    // Auto-capitalization: if at start of text or following '. ' or '? ' or '! ' (bypassed on password fields)
    if (!isStrictPrivacy && settings.autoCapsEnabled && /^[a-z]$/i.test(insertChar) && shiftState === ShiftState.OFF) {
      const before = text.substring(0, cursorPos);
      if (before.length === 0 || /(?:[.!?]\s*|\n)$/.test(before)) {
        insertChar = insertChar.toUpperCase();
      }
    }

    // Auto-reset single shift after one letter
    if (shiftState === ShiftState.ON) {
      setShiftState(ShiftState.OFF);
    }

    // Insert character
    const newText = text.substring(0, cursorPos) + insertChar + text.substring(cursorPos);
    const newPos = cursorPos + insertChar.length;

    // Check for space press triggers (Autocorrect, Shortcut expansion)
    if (insertChar === ' ') {
      // In strict privacy mode (TYPE_TEXT_VARIATION_PASSWORD / VISIBLE_PASSWORD), strictly bypass autocorrect & learning
      if (isStrictPrivacy) {
        setText(newText);
        setCursorPos(newPos);
        trackTypingActivity(1, 1);
        return;
      }

      let modifiedText = newText;
      let modifiedPos = newPos;

      // 1. Text shortcut expansion
      const wordsBefore = modifiedText.substring(0, modifiedPos - 1);
      const lastWordMatch = wordsBefore.match(/([\w'-]+)$/);
      if (lastWordMatch) {
        const word = lastWordMatch[1];
        const expansion = checkShortcut(word, settings.shortcuts);
        if (expansion) {
          const startIdx = lastWordMatch.index!;
          modifiedText = modifiedText.substring(0, startIdx) + expansion + ' ' + modifiedText.substring(modifiedPos);
          modifiedPos = startIdx + expansion.length + 1;
        } else if (settings.autoCorrectEnabled) {
          // 2. Auto-correction
          const fix = getAutoCorrection(word, new Set(), settings.personalDictionary);
          if (fix && fix.toLowerCase() !== word.toLowerCase()) {
            const startIdx = lastWordMatch.index!;
            modifiedText = modifiedText.substring(0, startIdx) + fix + ' ' + modifiedText.substring(modifiedPos);
            modifiedPos = startIdx + fix.length + 1;

            // Update stats
            setStats((prev) => ({
              ...prev,
              correctionCounts: {
                ...prev.correctionCounts,
                [word]: (prev.correctionCounts[word] || 0) + 1,
              },
            }));
          }
        }
      }

      setText(modifiedText);
      setCursorPos(modifiedPos);

      // Track word and character typing activity
      trackTypingActivity(1, 1);
      return;
    }

    setText(newText);
    setCursorPos(newPos);

    // Track character typing activity
    trackTypingActivity(1, 0);
  };

  // Handle Backspace with Gboard parity (UTF-16 surrogate & compound emoji safe)
  const handleBackspace = () => {
    playSoundAndHaptic();
    if (cursorPos === 0) return;
    pushHistory(text);

    const { newText, newPos } = deletePreviousGrapheme(text, cursorPos);
    setText(newText);
    setCursorPos(newPos);
  };

  // Handle Backspace Swipe-Left or Accelerated Repeat: Delete full word
  const handleDeleteWord = () => {
    playSoundAndHaptic();
    if (cursorPos === 0) return;
    pushHistory(text);

    const { newText, newPos } = deletePreviousWord(text, cursorPos);
    setText(newText);
    setCursorPos(newPos);
  };

  // Handle Enter / IME Action (EditorInfo.imeOptions commercial contract)
  const handleEnter = () => {
    playSoundAndHaptic();

    if (imeAction === 'actionSearch' || imeAction === 'IME_ACTION_SEARCH') {
      setLastImeActionFeedback(`Search executed for: "${text}"`);
      setTimeout(() => setLastImeActionFeedback(null), 3000);
      return;
    }
    if (imeAction === 'actionSend' || imeAction === 'IME_ACTION_SEND') {
      if (text.trim()) {
        setLastImeActionFeedback(`Message sent: "${text}"`);
        pushHistory(text);
        setText('');
        setCursorPos(0);
        setTimeout(() => setLastImeActionFeedback(null), 3000);
      } else {
        setLastImeActionFeedback('Cannot dispatch empty message');
        setTimeout(() => setLastImeActionFeedback(null), 2000);
      }
      return;
    }
    if (imeAction === 'actionDone' || imeAction === 'IME_ACTION_DONE') {
      setLastImeActionFeedback(`Input committed: "${text}" (Dismissed IME)`);
      setTimeout(() => setLastImeActionFeedback(null), 3000);
      return;
    }
    if (imeAction === 'actionGo' || imeAction === 'IME_ACTION_GO') {
      setLastImeActionFeedback(`Navigation dispatched for: "${text}"`);
      setTimeout(() => setLastImeActionFeedback(null), 3000);
      return;
    }
    if (imeAction === 'actionNext' || imeAction === 'IME_ACTION_NEXT') {
      const fieldSequence: EditorInputType[] = ['text', 'email', 'password', 'number'];
      const currentIdx = fieldSequence.indexOf(editorInputType);
      const nextType = fieldSequence[(currentIdx + 1) % fieldSequence.length];
      handleEditorInputTypeChange(nextType);
      setLastImeActionFeedback(`Advanced focus to next field (${nextType})`);
      setTimeout(() => setLastImeActionFeedback(null), 3000);
      return;
    }

    // Default / Return (newline insertion):
    pushHistory(text);
    const newText = text.substring(0, cursorPos) + '\n' + text.substring(cursorPos);
    setText(newText);
    setCursorPos(cursorPos + 1);
  };

  // Shift toggle
  const handleShiftToggle = () => {
    playSoundAndHaptic();
    if (shiftState === ShiftState.OFF) {
      setShiftState(ShiftState.ON);
    } else if (shiftState === ShiftState.ON) {
      setShiftState(ShiftState.CAPS);
    } else {
      setShiftState(ShiftState.OFF);
    }
  };

  // Move Cursor safely across grapheme boundaries (prevents splitting surrogate pairs or emojis)
  const handleMoveCursor = (offset: number) => {
    const newPos = getAdjacentGraphemePos(text, cursorPos, offset);
    setCursorPos(newPos);
  };

  // Select Suggestion
  const handleSelectSuggestion = (suggestedWord: string) => {
    playSoundAndHaptic();
    pushHistory(text);

    const before = text.substring(0, cursorPos);
    const after = text.substring(cursorPos);
    const match = before.match(/[\w'-]+$/);

    if (match) {
      const startIdx = match.index!;
      const newText = before.substring(0, startIdx) + suggestedWord + ' ' + after;
      setText(newText);
      setCursorPos(startIdx + suggestedWord.length + 1);
    } else {
      const newText = before + suggestedWord + ' ' + after;
      setText(newText);
      setCursorPos(before.length + suggestedWord.length + 1);
    }

    trackTypingActivity(suggestedWord.length + 1, 1);
  };

  // Apply Telugu Grammar Fix
  const handleApplyGrammarFix = (fix: { original: string; suggestion: string }) => {
    playSoundAndHaptic();
    pushHistory(text);

    const regex = new RegExp(fix.original, 'gi');
    const newText = text.replace(regex, fix.suggestion);
    setText(newText);
    setCursorPos(newText.length);
  };

  // Paste OTP
  const handlePasteOtp = (otp: string) => {
    playSoundAndHaptic();
    pushHistory(text);

    const newText = text.substring(0, cursorPos) + otp + ' ' + text.substring(cursorPos);
    setText(newText);
    setCursorPos(cursorPos + otp.length + 1);
  };

  // Smart Reply tap
  const handleSelectSmartReply = (reply: string) => {
    playSoundAndHaptic();
    pushHistory(text);

    const separator = text.length > 0 && !text.endsWith(' ') ? ' ' : '';
    const newText = text + separator + reply;
    setText(newText);
    setCursorPos(newText.length);
  };

  // Toolbar Actions
  const handleToolbarAction = (id: string) => {
    playSoundAndHaptic();

    if (id === 'undo') {
      handleUndo();
      return;
    }

    if (id === 'clear_history') {
      handleClearHistory();
      return;
    }

    if (id === 'settings' || id === 'theme') {
      setShowSettingsModal(true);
      return;
    }

    if (id === 'autocorrect') {
      if (isStrictPrivacy) {
        setLastImeActionFeedback('Auto-correct bypassed in password field (Strict Privacy Protocol)');
        setTimeout(() => setLastImeActionFeedback(null), 3000);
        return;
      }
      // Correct full sentence
      pushHistory(text);
      const { corrected, changedWords } = autoCorrectSentence(
        text,
        new Set(),
        settings.personalDictionary
      );
      setText(corrected);
      setCursorPos(corrected.length);
      if (changedWords.length > 0) {
        setStats((prev) => {
          const newCounts = { ...prev.correctionCounts };
          changedWords.forEach((w) => {
            newCounts[w] = (newCounts[w] || 0) + 1;
          });
          return { ...prev, correctionCounts: newCounts };
        });
      }
      return;
    }

    if (id === 'translate') {
      if (isStrictPrivacy) {
        setLastImeActionFeedback('Translation bypassed in password field (Strict Privacy Protocol)');
        setTimeout(() => setLastImeActionFeedback(null), 3000);
        return;
      }
      if (!text.trim()) {
        setLastImeActionFeedback('Type Telugu or English text first to translate');
        setTimeout(() => setLastImeActionFeedback(null), 2500);
        return;
      }
      // Translate between English and Telugu
      pushHistory(text);
      const { translated, changed } = translateText(text);
      if (changed) {
        setText(translated);
        setCursorPos(translated.length);
        setLastImeActionFeedback(`Translated: "${text}" → "${translated}"`);
      } else {
        setLastImeActionFeedback(`No dictionary match found for "${text.slice(0, 25)}"`);
      }
      setTimeout(() => setLastImeActionFeedback(null), 3000);
      return;
    }

    if (id === 'emoji') {
      setActivePanel(null);
      setKeyboardMode((prev) => (prev === 'emoji' ? 'qwerty' : 'emoji'));
      return;
    }

    // Toggle drawer panels (clipboard, phrases, stats, voice, customizer)
    if (activePanel === id) {
      setActivePanel(null);
    } else {
      setActivePanel(id);
      if (keyboardMode === 'emoji') setKeyboardMode('qwerty');
    }
  };

  // Add clip
  const handleAddClip = (clipText: string) => {
    const newItem: ClipItem = {
      id: `clip-${Date.now()}`,
      text: clipText,
      pinned: false,
      createdAt: Date.now(),
    };
    setClips((prev) => [newItem, ...prev.filter((c) => c.text !== clipText)].slice(0, 15));
  };

  // Toggle clip pin
  const handleTogglePin = (id: string) => {
    setClips((prev) =>
      prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c))
    );
  };

  // Delete clip
  const handleDeleteClip = (id: string) => {
    setClips((prev) => prev.filter((c) => c.id !== id));
  };

  // Paste clip
  const handlePasteClip = (clipText: string) => {
    playSoundAndHaptic();
    pushHistory(text);
    const newText = text.substring(0, cursorPos) + clipText + text.substring(cursorPos);
    setText(newText);
    setCursorPos(cursorPos + clipText.length);
    setActivePanel(null);
  };

  // Add phrase
  const handleAddPhrase = (newPhrase: string) => {
    setSettings((prev) => ({
      ...prev,
      quickPhrases: [...prev.quickPhrases, newPhrase],
    }));
  };

  // Delete phrase
  const handleDeletePhrase = (index: number) => {
    setSettings((prev) => ({
      ...prev,
      quickPhrases: prev.quickPhrases.filter((_, i) => i !== index),
    }));
  };

  // Theme container styles
  const getKeyboardContainerStyle = () => {
    if (settings.selectedTheme === ThemeId.CUSTOM && settings.customBackgroundUrl) {
      return {
        backgroundImage: `url(${settings.customBackgroundUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      };
    }
    return {};
  };

  const getKeyboardBgClass = () => {
    if (settings.selectedTheme === ThemeId.LIGHT) return 'bg-[#E5E9EC] text-neutral-900 border-t border-neutral-300 shadow-lg';
    if (settings.selectedTheme === ThemeId.BLUE) return 'bg-[#08182B] text-blue-100 border-t border-[#102e50] shadow-lg';
    if (settings.selectedTheme === ThemeId.GREEN) return 'bg-[#071E0C] text-green-100 border-t border-[#103818] shadow-lg';
    if (settings.selectedTheme === ThemeId.AMOLED) return 'bg-black text-white border-t border-neutral-900';
    if (settings.selectedTheme === ThemeId.BLACK) return 'bg-[#101010] text-white border-t border-neutral-800';
    return 'bg-[#20272E] text-neutral-100 border-t border-[#2d3640] shadow-lg';
  };

  return (
    <div id="app_root" className="flex flex-col min-h-screen bg-neutral-100 dark:bg-[#12161A] text-neutral-900 dark:text-neutral-100 selection:bg-blue-500 selection:text-white">
      {/* Top Header Bar */}
      <header className="w-full flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 bg-white/70 dark:bg-[#181D22]/80 backdrop-blur-md sticky top-0 z-40">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-sm">
            B
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight flex items-center gap-1.5">
              <span>BabelKey</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-blue-500/15 text-blue-600 dark:text-blue-400 font-semibold">
                Multilingual
              </span>
            </h1>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-none">
              Telugu & English Smart Custom Keyboard
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Quick theme switcher */}
          <button
            id="btn_quick_theme"
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                selectedTheme: prev.selectedTheme === ThemeId.LIGHT ? ThemeId.DARK : ThemeId.LIGHT,
              }))
            }
            title="Toggle Light/Dark Theme"
            className="p-2 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            {settings.selectedTheme === ThemeId.LIGHT ? <Moon size={16} /> : <Sun size={16} />}
          </button>

          {/* Settings button */}
          <button
            id="btn_open_settings"
            onClick={() => setShowSettingsModal(true)}
            className="p-2 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-blue-600 dark:text-blue-400 transition-colors flex items-center space-x-1.5 text-xs font-semibold"
          >
            <Settings size={16} />
            <span className="hidden sm:inline">Settings</span>
          </button>
        </div>
      </header>

      {/* Main Content Area: Typing Playground */}
      <main className="flex-1 flex flex-col justify-start pb-4 overflow-y-auto">
        <TypingArea
          text={text}
          cursorPos={cursorPos}
          onTextChange={(newText, newPos) => {
            const charDiff = newText.length - text.length;
            if (charDiff > 0) {
              const oldWords = text.trim() ? text.trim().split(/\s+/).length : 0;
              const newWords = newText.trim() ? newText.trim().split(/\s+/).length : 0;
              const wordDiff = Math.max(0, newWords - oldWords);
              trackTypingActivity(charDiff, wordDiff);
            }
            setText(newText);
            setCursorPos(newPos);
          }}
          incomingMessage={incomingMessage}
          onCycleIncomingMessage={() => setSampleIdx((prev) => (prev + 1) % SAMPLE_PROMPTS.length)}
          onQuickSampleInsert={(sample) => {
            pushHistory(text);
            const newT = text ? `${text} ${sample}` : sample;
            setText(newT);
            setCursorPos(newT.length);
          }}
          historyCount={history.length}
          onUndo={handleUndo}
          onClearHistory={handleClearHistory}
          historyClearedNotice={historyClearedNotice}
          editorInputType={editorInputType}
          onChangeEditorInputType={handleEditorInputTypeChange}
          imeAction={imeAction}
          onChangeImeAction={setImeAction}
          lastImeActionFeedback={lastImeActionFeedback}
        />
      </main>

      {/* Bottom Floating Keyboard Container */}
      <div
        id="custom_keyboard_container"
        style={getKeyboardContainerStyle()}
        className={`w-full max-w-2xl mx-auto rounded-t-3xl overflow-hidden transition-all duration-150 flex flex-col justify-end ${getKeyboardBgClass()}`}
      >
        {/* Quick Toolbar */}
        <Toolbar
          themeId={settings.selectedTheme}
          enabledButtons={settings.toolbarButtons}
          activePanel={activePanel || (keyboardMode === 'emoji' ? 'emoji' : null)}
          onButtonClick={handleToolbarAction}
          onToggleCustomizer={() => handleToolbarAction('customizer')}
          canUndo={history.length > 0}
          historyCount={history.length}
          onClearHistory={handleClearHistory}
        />

        {/* Suggestion Bar */}
        <SuggestionBar
          themeId={settings.selectedTheme}
          suggestions={suggestions}
          smartReplies={smartReplies}
          grammarError={grammarError}
          otpDetected={otpDetected}
          onSelectSuggestion={handleSelectSuggestion}
          onApplyGrammarFix={handleApplyGrammarFix}
          onPasteOtp={handlePasteOtp}
          onSelectSmartReply={handleSelectSmartReply}
          currentWord={currentWord}
          editorInputType={editorInputType}
        />

        {/* Drawer Panels or Active Keyboard Layout */}
        <div style={{ height: `${settings.keyboardHeightDp}px` }} className="flex flex-col justify-center items-center w-full overflow-hidden">
          {activePanel === 'clipboard' && (
            <ClipboardDrawer
              themeId={settings.selectedTheme}
              clips={clips}
              onPasteClip={handlePasteClip}
              onTogglePin={handleTogglePin}
              onDeleteClip={handleDeleteClip}
              onAddClip={handleAddClip}
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'phrases' && (
            <PhrasesPanel
              themeId={settings.selectedTheme}
              phrases={settings.quickPhrases}
              onSelectPhrase={(phrase) => {
                handlePasteClip(phrase);
                setActivePanel(null);
              }}
              onAddPhrase={handleAddPhrase}
              onDeletePhrase={handleDeletePhrase}
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'stats' && (
            <StatsPanel
              themeId={settings.selectedTheme}
              stats={stats}
              historyCount={history.length}
              onClearHistory={handleClearHistory}
              onResetStats={() =>
                setStats({
                  totalWords: 0,
                  totalCharacters: 0,
                  sessionStartTime: Date.now(),
                  lastActiveTime: Date.now(),
                  activeTypingSeconds: 0,
                  recentActivity: [],
                  correctionCounts: {},
                  dailyWords: {},
                })
              }
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'voice' && (
            <VoiceTypingPanel
              themeId={settings.selectedTheme}
              onTranscriptReceived={(spokenText) => {
                pushHistory(text);
                const separator = text.length > 0 && !text.endsWith(' ') ? ' ' : '';
                const newText = text + separator + spokenText;
                setText(newText);
                setCursorPos(newText.length);
              }}
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'customizer' && (
            <ToolbarCustomizer
              themeId={settings.selectedTheme}
              enabledButtons={settings.toolbarButtons}
              onUpdateToolbar={(newButtons) => setSettings((prev) => ({ ...prev, toolbarButtons: newButtons }))}
              onClose={() => setActivePanel(null)}
            />
          )}

          {/* When no drawer panel is active, show the virtual keyboard */}
          {!activePanel && (
            <>
              {keyboardMode === 'emoji' ? (
                <EmojiKeyboard
                  themeId={settings.selectedTheme}
                  onSelectEmoji={(emoji) => handleKeyPress(emoji)}
                  onBackspace={handleBackspace}
                  onClose={() => setKeyboardMode('qwerty')}
                />
              ) : (
                <KeyboardLayout
                  mode={keyboardMode}
                  themeId={settings.selectedTheme}
                  shiftState={shiftState}
                  fontSize={settings.keyFontSize ?? 16}
                  height={settings.keyboardHeightDp}
                  imeAction={imeAction}
                  onKeyPress={handleKeyPress}
                  onBackspace={handleBackspace}
                  onDeleteWord={handleDeleteWord}
                  onEnter={handleEnter}
                  onShiftToggle={handleShiftToggle}
                  onSwitchMode={(mode) => {
                    setActivePanel(null);
                    setKeyboardMode(mode);
                  }}
                  onMoveCursor={handleMoveCursor}
                />
              )}
            </>
          )}
        </div>
      </div>

      {/* Settings Hub Modal */}
      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newVals) => setSettings((prev) => ({ ...prev, ...newVals }))}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
};
